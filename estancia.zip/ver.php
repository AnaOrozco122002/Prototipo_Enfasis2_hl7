<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mostrar Datos del paciente</title>
  <style>
 
    table {

      margin: 0 auto; /*para poner la tabla en el centro
    }
  </style>
</head>
<body>

  <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    <tr>
      <td valign="top" align=left width=70%>
        <table width="100%" align=center border=0>
          <tr>
            <td valign="top" align=center width=30%>
              <img src="img/clinica.jpg" border=0 width=1200 height=250> 
            </td>
          </tr>
        </table>
      </td>
    </tr>
    
    <tr valign="top">
      <td height="15%" align="center" bgcolor="#FFFFFF" class="_espacio_celdas" style="color: #FFFFFF; font-weight: bold">
        <font FACE="arial" SIZE=1.8 color="#000044"> <b><h1>Ver infromación general del paciente</h1></b></font>  
      </td>
    </tr>
    
    <!-- Formulario para ingresar el ID del paciente -->
    <tr valign="top">
      <td valign="top" align=center width=70%>
        <form id="formPaciente">
          <label for="idPaciente">Ingrese el ID del Paciente:</label>
          <input type="text" id="idPaciente" name="idPaciente" required>
          <button style="background-color: #9fd5d1;" type="submit">Consultar</button>
        </form>
      </td>
    </tr>
    
    
    
  </table>

  <!-- Contenedor para mostrar los datos -->
  <div id="resultado"></div>

  <script>
    // Función para manejar el envío del formulario
    const handleSubmit = (event) => {
      event.preventDefault();

      // Obtener el valor del campo de entrada
      const patientId = document.getElementById('idPaciente').value;

      // Realizar la solicitud Fetch para obtener información sobre el paciente
      fetch(`https://hapi.fhir.org/baseR4/Patient/${patientId}`)
        .then(response => response.json())
        .then(data => {
          // Limpiar el contenedor de resultados
          contenedorResultado.innerHTML = '';

          // Crear una tabla para mostrar los datos
          const tabla = document.createElement('table');
           tabla.border = '1';

          // Crear una fila para el encabezado
          const filaEncabezado = tabla.insertRow();
          const celdaEncabezado = filaEncabezado.insertCell();
          celdaEncabezado.textContent = 'Datos del Paciente';
          celdaEncabezado.colSpan = '2';
          celdaEncabezado.style.fontWeight = 'bold';
          celdaEncabezado.style.textAlign = 'center';

          // Crear filas y celdas para cada propiedad
          const propiedades = ['Nombre', 'Cédula', 'Fecha de Nacimiento', 'Género', 'Dirección', 'Celular'];
          const valores = [
            `${data.name[0].given.join(' ') + ' ' + data.name[0].family}`,
            `${data.identifier[0].value}`,
            `${data.birthDate}`,
            `${data.gender}`,
            `${data.address && data.address[0] ? data.address[0].text : 'Dirección no disponible'}`,
            `${data.telecom[0].value}`,
          ];

          for (let i = 0; i < propiedades.length; i++) {
            const fila = tabla.insertRow();
            const celdaPropiedad = fila.insertCell();
            celdaPropiedad.textContent = propiedades[i];
            const celdaValor = fila.insertCell();
            celdaValor.textContent = valores[i];
          }

          // Agregar la tabla al contenedor
          contenedorResultado.appendChild(tabla);
        })
        .catch(error => {
          console.error('Error al obtener datos del paciente:', error);
        });
    };

    // Accede al formulario y agrega un listener para el evento de envío
    const formPaciente = document.getElementById('formPaciente');
    formPaciente.addEventListener('submit', handleSubmit);

    // Accede al elemento con el id "resultado"
    const contenedorResultado = document.getElementById('resultado');
  </script>
  
  <table width=10% align=center border=0>
           <tr>  
             <td width=50%></td>                                                                       
             <td align=center>
                 <form method=POST action="index.php"> 
            
                 <input style="background-color: #9fd5d1;" type="submit" color= blue value="Volver" name="Volver">
                 
       
             </td>  
             
           </tr>

        </table>

</body>
</html>
