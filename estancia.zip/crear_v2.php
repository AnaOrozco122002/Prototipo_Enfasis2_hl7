<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
              <table width="100%" align=center border=0>
            	   <tr>
                  <td valign="top" align=center width=30%>
                     <img src="img/clinica.jpg" border=0 width=1200 height=250> 
             	    </td>
                  
           	    </tr>
         	    </table>
           </td>
	     </tr>
	     
	     <tr valign="top">
             <td height="15%" align="center" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=1.8 color="#000044"> <b><h1>Ingreso de paciente nuevo</h1></b></font>  
			  
		       </td>
             	    </tr>
	     
     </table>
  
    &nbsp;&nbsp;&nbsp;&nbsp;

		    
		    
		    
  <title>Agregar y Mostrar Paciente con Fetch</title>
  <style>
    /* Estilos (pueden variar según tus preferencias) */
    body {
      font-family: 'Arial', sans-serif;
      margin: 20px;
      background-color: #f4f4f4;
    }

    #datosPaciente {
      background-color: #fff;
      padding: 70px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      max-width: 800px;
      margin: 0 auto;
    }

    p {
      margin: 0 0 10px;
    }

    h2 {
      color: #333;
    }
  </style>
</head>
<body>

  <!-- Formulario para ingresar datos del paciente -->
  <div id="datosPaciente">

    <form id="formularioPaciente">
        
        
        <tr valign="top">
                <td width="50%" height="20%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
			    <font FACE="arial" SIZE=2 color="#000044"> <b><h1>Ingrese la siguiente infromación del paciente: </h1></b></font>  
		       </td>
	    </tr>

   	     <tr>
                  <td colspan=2 width="30%" height="25%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                      
                    
                <table width=50% border=1 align=center>
                    
                <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Nombre del Paciente</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="text" id="nombre" name="nombre" required>
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Apellido del Paciente</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="text" id="apellido" name="apellido" required>
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Cédula</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="number" id="cedula" name="cedula"> 
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Fecha Nacimiento: </b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
                    <input type="date" id="fechaNacimiento" name="fechaNacimiento" required>
				</td>	
	            </tr>
	            
                       
                <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Género</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				<select id="genero" name="genero" required onchange="handleSelectionChange(this)">
				    <option value="female"> <?php echo "Femenino"; ?></option> 
				    <option value="male"> <?php echo "Masculino"; ?></option> 
				    <option value="other"> <?php echo "Otro"; ?></option> 
                  </select>
				</td>
	            </tr>       
                       
                       
                <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Dirección</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="text" id="direccion" name="direccion"> 
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Teléfono o celular</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="number" id="telecom" name="telecom"> 
				</td>	
	            </tr>
	            
	             <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Nombre de contacto emergencia</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="text" id="NombreContancto" name="NombreContacto"> 
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Apellido de contacto emergencia</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="text" id="ApellidoContancto" name="ApellidoContacto"> 
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Apellido de contacto emergencia</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="number" id="telefonoContancto" name="telefonoContacto"> 
				</td>	
	            </tr>
	             
            

             </table>
        
        <table width=30% height="10%" align=center border=0>
           <br>  
           </br>
           <tr>  
             <td width=10% ></td>                                                                       
             <td align=center>
                
                <button style="background-color: #9fd5d1;" type="button" onclick="agregarPaciente()">Agregar Paciente</button>
       
             </td>  
             
           </tr>

        </table>
  
      
    </form>
  </div>

  <script>
    function agregarPaciente() {
      // Obtener valores del formulario
      const nombre = document.getElementById('nombre').value;
      const apellido = document.getElementById('apellido').value;
      const cedula = document.getElementById('cedula').value;
      const fechaNacimiento = document.getElementById('fechaNacimiento').value;
      const genero = document.getElementById('genero').value;
      const direccion = document.getElementById('direccion').value;
      const telecom = document.getElementById('telecom').value;
      const NombreContacto = document.getElementById('NombreContacto').value;
      const ApellidoContacto = document.getElementById('ApellidoContacto').value;
      const telefonoContacto = document.getElementById('telefonoContacto').value;

      // Crear objeto con los datos del paciente
      const nuevoPaciente = {
        resourceType: 'Patient',
        name: [
          {
            given: [nombre],
            family: [apellido], 
          }
        ],
        identifier: [
            {
              system: "https://www.registraduria.gov.co/",
              value: cedula,
              use: "official",
            }
        ],
        birthDate: fechaNacimiento,
        
        telecom: [
            {
              system: 'phone',
              value: telecom,
              use: 'home',
            }
        
        ],
        
        gender: genero,

        address: [
          {
            text: direccion,
          }
        ],
        
        contact: [
            {
                name: {
                use: "official",
                text: "Emergency Contact",
                family: ApellidoContacto,
                given: [NombreContacto]
              },
              
              telecom: [
                {
                  system: "phone",
                  value: telefonoContacto,
                  use: "home"
                }
              ]
            }
          ]
      };
      

      // Realizar la solicitud Fetch para agregar el paciente
      fetch('https://hapi.fhir.org/baseR4/Patient', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(nuevoPaciente),
      })
        .then(response => {
          if (!response.ok) {
            throw new Error(`Error en la solicitud: ${response.statusText}`);
          }
          return response.json();
        })
        .then(pacienteCreado => {
          console.log('Paciente agregado exitosamente:', pacienteCreado);

          // Accede al elemento con el id "datosPaciente"
          const contenedorDatosPaciente = document.getElementById('datosPaciente');
          
          

          // Crear elementos HTML para mostrar los datos del paciente
          const parrafoID = document.createElement('p');
          parrafoID.textContent = `ID: ${pacienteCreado.id}`;
          
          const parrafoNombre = document.createElement('p');
          parrafoNombre.textContent = `Nombre: ${pacienteCreado.name[0].given.join(' ') + ' ' + pacienteCreado.name[0].family}`;
          
          const parrafoCedula = document.createElement('p');
          parrafoCedula.textContent = `Cedula: ${pacienteCreado.identifier[0].value}`;

          const parrafoFechaNacimiento = document.createElement('p');
          parrafoFechaNacimiento.textContent = `Fecha de Nacimiento: ${pacienteCreado.birthDate}`;
          
          const parrafoGenero = document.createElement('p');
          parrafoGenero.textContent = `Genero: ${pacienteCreado.gender}`;

          const parrafoDireccion = document.createElement('p');
          parrafoDireccion.textContent = `Dirección: ${pacienteCreado.address && pacienteCreado.address[0] ? pacienteCreado.address[0].text : 'Dirección no disponible'}`;

          const parrafoCelular = document.createElement('p');
          parrafoCelular.textContent = `Celular: ${pacienteCreado.telecom[0].value}`;
          
          // Agrega los elementos al contenedor
          contenedorDatosPaciente.appendChild(parrafoID);
          contenedorDatosPaciente.appendChild(parrafoNombre);
          contenedorDatosPaciente.appendChild(parrafoCedula);
          contenedorDatosPaciente.appendChild(parrafoFechaNacimiento);
          contenedorDatosPaciente.appendChild(parrafoDireccion);
          contenedorDatosPaciente.appendChild(parrafoGenero);
          contenedorDatosPaciente.appendChild(parrafoCelular);
        })
        .catch(error => {
          console.error('Error al agregar paciente:', error);
        });
    }
  </script>

  

         

</body>
</html>
