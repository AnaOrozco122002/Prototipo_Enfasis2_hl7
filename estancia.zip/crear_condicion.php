<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
              <table width="100%" align=center border=0>
            	   <tr>
                  <td valign="top" align=center width=30%>
                     <img src="img/clinica.jpg" border=0 width=1200 height=250> 
             	    </td>
                  
           	    </tr>
         	    </table>
           </td>
	     </tr>
	     
	     <tr valign="top">
             <td height="15%" align="center" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=1.8 color="#000044"> <b><h1>Registrar Condición</h1></b></font>  
			  
		       </td>
             	    </tr>
	     
     </table>
  
    &nbsp;&nbsp;&nbsp;&nbsp;

		    
		    
		    
  <title>Agregar y Mostrar Paciente con Fetch</title>
  <style>
    /* Estilos (pueden variar según tus preferencias) */
    body {
      font-family: 'Arial', sans-serif;
      margin: 20px;
      background-color: #f4f4f4;
    }

    #datosPaciente {
      background-color: #fff;
      padding: 70px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      max-width: 800px;
      margin: 0 auto;
    }

    p {
      margin: 0 0 10px;
    }

    h2 {
      color: #333;
    }
  </style>
</head>
<body>

  <!-- Formulario para ingresar datos de la condición -->
  <div id="datosCondicion">

    <form id="formularioCondicion">
        
        <tr valign="top">
                <td width="70%" height="20%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
			    <font FACE="arial" SIZE=2 color="#000044"> <b><h1>Registrar la información de la condición del paciente: </h1></b></font>  
		       </td>
	    </tr>

   	     <tr>
                  <td colspan=2 width="50%" height="25%" align="left" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                      
                    
                <table width=70% border=1 align=center>
                
                <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Id del paciente</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="number" id="idPaciente" name="idPaciente" required>
				</td>	
	            </tr>
                
                <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Condición</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
                    <select id="idCondicion" name="idCondicion" required>
                        <option value= " "> <?php echo " "; ?></option> 
                        <option value= 2295008> <?php echo "Fractura cerrada del extremo superior del antebrazo"; ?></option> 
				        <option value= 2919008> <?php echo "Náuseas, vómitos y diarrea"; ?></option> 
				        <option value=2070002> <?php echo "Sensación de ardor en el ojo"; ?></option> 
				        <option value=3723001> <?php echo "Artritis"; ?></option> 
                    </select>
				</td>	
	            </tr>
	            
	             <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Fecha de Inicio de la condición</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
                    <input type="date" id="fechaInicio" name="fechaInicio">
				</td>	
	            </tr>
	            
                <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Fecha de Regsitro de la condición</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
                    <input type="date" id="fechaRegistro" name="fechaRegistro">
				</td>	
	            </tr>
                       
                <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Gravedad</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
                    <select id="gravedad" name="gravedad" required>
                        <option value="mild">Leve</option>
                        <option value="moderate">Moderado</option>
                        <option value="severe">Severo</option>
                    </select>
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Sitio del Cuerpo</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
                    <select id="bodysite" name="bodysite" required>
                        <option value=" "> <?php echo "NA"; ?></option> 
                        <option value=7769000> <?php echo "Pie Derecho"; ?></option> 
				        <option value=8966001> <?php echo "Ojo izquierdo"; ?></option> 
				        <option value=40768003> <?php echo "Brazo izquierdo"; ?></option> 
                    </select>
				</td>	
	            </tr>
	            
	           <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Nota</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <input type="text" id="note" name="note" required>
				</td>	
	            </tr>
	            
	            <tr>	
				<td bgcolor="#9fd5d1" align=center> 
				  <font FACE="arial" SIZE=2 color="#000044"> <b>Medico</b></font>  
				</td>	
				<td bgcolor="#EEEEEE" align=center> 
				  <select id="medico" name="medico" required>
                        <option value=38827276> <?php echo "Juan Pérez - EPS Sanitas"; ?></option> 
				        <option value=38827278> <?php echo "Juliana Montes - Clínica la estancia"; ?></option> 
                    </select>
				</td>	
	            </tr>

             </table>
        
        <table width=30% height="10%" align=center border=0>
           <br>  
           </br>
           <tr>  
             <td width=10% ></td>                                                                       
             <td align=center>
                
                <button style="background-color: #D1E8FF;" type="button" onclick="agregarCondicion()">Agregar Condición</button>
       
             </td>  
             
           </tr>

        </table>
  
      
    </form>
  </div>

  <script>
   function agregarCondicion() {
      // Obtener valores del formulario
      const idPaciente = document.getElementById('idPaciente').value;
      const idCondicion = document.getElementById('idCondicion').value;
      const fechaInicio = document.getElementById('fechaInicio').value;
      const fechaRegistro = document.getElementById('fechaRegistro').value;
      const gravedad = document.getElementById('gravedad').value;
      const idBodysite = document.getElementById('bodysite').value;
      const note = document.getElementById('note').value;
      const medico = document.getElementById('medico').value;
      
      
      let nombreCondicion; 

        if (idCondicion == 2295008) {
            nombreCondicion = "Fractura cerrada del extremo superior del antebrazo";
        } else if (idCondicion == 2919008) {
            nombreCondicion = "Náuseas, vómitos y diarrea";
        } else if (idCondicion == 2070002) {
            nombreCondicion = "Sensación de ardor en el ojo";
        } else if (idCondicion == 3723001) {
            nombreCondicion = "Artritis";
        } else {
            nombreCondicion = "Condición Desconocida";
        }

        console.log('Nombre de la condición:', nombreCondicion);
        
        let nombreBody; 

        if (idBodysite == 7769000) {
            nombreBody = "Pie derecho";
        } else if (idBodysite == 8966001) {
            nombreBody = "Ojo izquierdo";
        } else if (idBodysite == 40768003) {
            nombreBody = "Brazo izquierdo";
        } else {
            nombreBody = "NA";
        }

        console.log('Nombre parte del cuerpo:', nombreBody);

        let nombreGravedad; 

        if (gravedad == 'mild') {
            nombreGravedad = "Leve";
        } else if (gravedad == 'moderate') {
            nombreGravedad = "Moderado";
        } else if (gravedad == 'severe') {
            nombreGravedad = "Severo";
        } else {
            nombreGravedad = "Desconocido";  
        }
        
        let nombreMedico; 

        if (medico == '38827276') {
            nombreMedico = "Juan Pérez - EPS Sanitas";
        } else if (medico == '38827278') {
            nombreMedico = "Juliana Montes - Clínica la estancia";
        } else {
            nombreMedico = "Desconocido";  
        }
        
      
      var referenciaPaciente = "Patient/" + idPaciente;
      console.log(referenciaPaciente);
      
      var referenciaMedico = "Practitioner/" + medico;
      console.log(referenciaMedico);
     
     
      // Crear objeto con los datos del paciente
      const nuevaCondicion = {
          resourceType: 'Condition',
          code: {
            coding: [
              {
                system: "http://snomed.info/sct",
                code: idCondicion,
                display: nombreCondicion,
              }
            ],
            text: nombreCondicion
          },
          subject: {
            reference: referenciaPaciente
          },
          onsetDateTime: fechaInicio,
          recordedDate: fechaRegistro,
          recorder: {
            reference: referenciaMedico,
            display: nombreMedico,
          },
          severity: {
            coding: [
              {
                system: "http://snomed.info/sct",
                code: gravedad,
                display: nombreGravedad
              }
            ],
            text: nombreGravedad
          },
          bodySite: [
            {
              coding: [
                {
                  system: "http://snomed.info/sct",
                  code: bodysite,
                  display: nombreBody,
                }
              ],
              text: nombreBody
            }
          ],
          note: [
            {
              text: note
            }
          ]
      };
      
      
      

      // Realizar la solicitud Fetch para agregar el paciente
     
      fetch('https://hapi.fhir.org/baseR4/Condition', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(nuevaCondicion),
      })
        .then(response => {
          if (!response.ok) {
            throw new Error(`Error en la solicitud: ${response.statusText}`);
          }
          return response.json();
        })
        .then(condicionCreada => {
          console.log('Condicion agregada exitosamente:', condicionCreada);

          // Accede al elemento con el id "datosPaciente"
          /*const contenedorDatosPaciente = document.getElementById('datosPaciente');
          
          

          // Crear elementos HTML para mostrar los datos del paciente
          const parrafoID = document.createElement('p');
          parrafoID.textContent = `ID: ${pacienteCreado.id}`;
          
          const parrafoNombre = document.createElement('p');
          parrafoNombre.textContent = `Nombre: ${pacienteCreado.name[0].given.join(' ') + ' ' + pacienteCreado.name[0].family}`;
          
          const parrafoCedula = document.createElement('p');
          parrafoCedula.textContent = `Cedula: ${pacienteCreado.identifier[0].value}`;

          const parrafoFechaNacimiento = document.createElement('p');
          parrafoFechaNacimiento.textContent = `Fecha de Nacimiento: ${pacienteCreado.birthDate}`;
          
          const parrafoGenero = document.createElement('p');
          parrafoGenero.textContent = `Genero: ${pacienteCreado.gender}`;

          const parrafoDireccion = document.createElement('p');
          parrafoDireccion.textContent = `Dirección: ${pacienteCreado.address && pacienteCreado.address[0] ? pacienteCreado.address[0].text : 'Dirección no disponible'}`;

          const parrafoCelular = document.createElement('p');
          parrafoCelular.textContent = `Celular: ${pacienteCreado.telecom[0].value}`;
          
          // Agrega los elementos al contenedor
          contenedorDatosPaciente.appendChild(parrafoNombre);
          contenedorDatosPaciente.appendChild(parrafoCedula);
          contenedorDatosPaciente.appendChild(parrafoFechaNacimiento);
          contenedorDatosPaciente.appendChild(parrafoDireccion);
          contenedorDatosPaciente.appendChild(parrafoGenero);
          contenedorDatosPaciente.appendChild(parrafoCelular);*/
        })
        .catch(error => {
          console.error('Error al agregar condición:', error);
        });
    }
    
  </script>

      &nbsp;&nbsp;&nbsp;&nbsp;

         <table width=10% align=center border=0>
           <tr>  
             <td width=50%></td>                                                                       
             <td align=center>
                 <form method=POST action="index.php"> 
            
                 <input style="background-color: #8DDFEC;" type="submit" color= blue value="Volver" name="Volver">
                 
       
             </td>  
             
           </tr>

        </table>

</body>
</html>
