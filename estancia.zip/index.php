<?php
echo '
    
';


			           
?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
     <html>
       <head>
           <title> Clinica la Estancia</title>
         
        </head>
       <body>
        <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
              <table width="100%" align=center border=0>
            	   <tr>
                  <td valign="top" align=center width=30%>
                     <img src="img/clinica.jpg" border=0 width=1000 height=300> 
             	    </td>
                  
           	    </tr>
         	    </table>
           </td>
	     </tr>
     </table>
     
         <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
   
	  	   <tr valign="top">
             <td height="15%" align="center" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=1.8 color="#000044"> <b><h1>¿Qué funcionalidad requiere?</h1></b></font>  
			  
		       </td>
             	    </tr>
              
		    </table>
		    
		   &nbsp;&nbsp;&nbsp;&nbsp;
     
        <table width="100%">
  	      <tr>
  	          
          <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

			        <a href="crear.php"><img src="img/crear_paciente.jpeg" width="45%" height="45%" border=0></a>
		  </th>  	          
  	      <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">    
            
			        <a href="ver.php"><img src="img/ver_paciente.jpeg" width="45%" height="45%" border=0></a>
          </th>

		  <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

		            <a href="crear_condicion.php">
                      <img src="img/crear_condicion.jpeg" width="50%" height="50%" border="0">
                    </a>
          </th>
          <th colspan=1 width="20%" height="20%" align="center" bgcolor="#FFFFFF">

			        <a href="ver_condicion.php"><img src="img/ver_condicion.jpeg" width="48%" height="48%" border=0></a>
		  </th>
     
		  </tr>
       
        </table>
        
        

        
        <hr>
        
      </form>