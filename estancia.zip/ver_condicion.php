<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mostrar Condiciones del Paciente</title>
  <style>
    table {
      margin: 0 auto; /*para poner la tabla en el centro*/
    }
  </style>
</head>
<body>

  <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    <tr>
      <td valign="top" align=left width=70%>
        <table width="100%" align=center border=0>
          <tr>
            <td valign="top" align=center width=30%>
              <img src="img/clinica.jpg" border=0 width=1200 height=250> 
            </td>
          </tr>
        </table>
      </td>
    </tr>
    
    <tr valign="top">
      <td height="15%" align="center" bgcolor="#FFFFFF" class="_espacio_celdas" style="color: #FFFFFF; font-weight: bold">
        <font FACE="arial" SIZE=1.8 color="#000044"> <b><h1>Ver las condiciones del paciente</h1></b></font>  
      </td>
    </tr>
    
    <!-- Formulario para ingresar el ID del paciente -->
    <tr valign="top">
      <td valign="top" align=center width=70%>
        <form id="formPaciente">
          <label for="idPaciente">Ingrese el ID del Paciente:</label>
          <input type="text" id="idPaciente" name="idPaciente" required>
          <button style="background-color: #9fd5d1;" type="submit">Buscar</button>
        </form>
      </td>
    </tr>
  </table>

  <!-- Contenedor para mostrar los datos -->
  <div id="resultado"></div>

  <script>
    const handleSubmit = (event) => {
      event.preventDefault();

      const patientId = document.getElementById('idPaciente').value;

      fetch(`https://hapi.fhir.org/baseR4/Condition?subject=Patient/${patientId}`)
        .then(response => response.json())
        .then(data => {
          const contenedorResultado = document.getElementById('resultado');
          contenedorResultado.innerHTML = '';

          if (data.entry && data.entry.length > 0) {
            const tabla = document.createElement('table');
            tabla.border = '1';

            const filaEncabezado = tabla.insertRow();
            const celdaEncabezado = filaEncabezado.insertCell();
            celdaEncabezado.textContent = 'Condiciones del Paciente';
            celdaEncabezado.colSpan = '7';
            celdaEncabezado.style.fontWeight = 'bold';
            celdaEncabezado.style.textAlign = 'center';

            const propiedades = ['Fecha de Reporte', 'Condición', 'Fecha de Inicio', 'Gravedad', 'Sitio del cuerpo', 'Nota', 'Medico'];

            // Encabezado de la tabla
            const filaEncabezadoCondiciones = tabla.insertRow();
            propiedades.forEach(propiedad => {
              const celdaEncabezadoCondicion = filaEncabezadoCondiciones.insertCell();
              celdaEncabezadoCondicion.textContent = propiedad;
              celdaEncabezadoCondicion.style.fontWeight = 'bold';
            });

            // Datos de las condiciones
            data.entry.forEach(entry => {
              const condition = entry.resource;

              const fila = tabla.insertRow();
              
              const celdaFechaR = fila.insertCell();
              celdaFechaR.textContent = condition.recordedDate;
              
              const celdaCondicion = fila.insertCell();
              celdaCondicion.textContent = condition.code.coding[0].display;

              const celdaInicio = fila.insertCell();
              celdaInicio.textContent = condition.onsetDateTime;

              const celdaGravedad = fila.insertCell();
              celdaGravedad.textContent = condition.severity.coding[0].display;

              const celdaBody = fila.insertCell();
              
                  celdaBody.textContent = condition.bodySite[0].coding[0].display;
               

              const celdaNota = fila.insertCell();
              celdaNota.textContent = condition.note ? condition.note[0].text : '';
              
              
              const celdaMedico = fila.insertCell();
              if (condition.recorder && condition.recorder.display) {
                    nombreMedico = condition.recorder.display;
                } else {
                    nombreMedico = "No disponible";
                }
              celdaMedico.textContent = nombreMedico;
              
            });

            contenedorResultado.appendChild(tabla);
          } else {
            contenedorResultado.textContent = 'No se encontraron condiciones para el paciente.';
          }
        })
        .catch(error => {
          console.error('Error al obtener condiciones del paciente:', error);
        });
    };

    const formPaciente = document.getElementById('formPaciente');
    formPaciente.addEventListener('submit', handleSubmit);
  </script>
           <table width=10% align=center border=0>
           <tr>  
             <td width=50%></td>                                                                       
             <td align=center>
                 <form method=POST action="index.php"> 
            
                 <input style="background-color: #9fd5d1C;" type="submit" color= blue value="Volver" name="Volver">
                 
       
             </td>  
             
           </tr>

        </table>
</body>
</html>
