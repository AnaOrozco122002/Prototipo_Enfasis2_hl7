<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  
   
  <table width="100%" align=center cellpadding=5 border=0 bgcolor="#FFFFFF">
    	   <tr>
           <td valign="top" align=left width=70%>
              <table width="100%" align=center border=0>
            	   <tr>
                  <td valign="top" align=center width=30%>
                     <img src="img/sanitass.png" border=0 width=1200 height=250> 
             	    </td>
                  
           	    </tr>
         	    </table>
           </td>
	     </tr>
	     
	     <tr valign="top">
             <td height="15%" align="center" 				
                    bgcolor="#FFFFFF" class="_espacio_celdas" 					
                    style="color: #FFFFFF; 
			             font-weight: bold">
                <font FACE="arial" SIZE=1.8 color="#000044"> <b><h1>Creación de Diagnostico</h1></b></font>  
			  
		       </td>
             	    </tr>
	     
     </table>
  
    &nbsp;&nbsp;&nbsp;&nbsp;

		    
  
  
  
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      background-color: #f4f4f4;
    }

    h2 {
      color: #333;
    }

    form {
      max-width: 400px;
      margin: 0 auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    label {
      margin-bottom: 5px;
      color: #333;
      display: block;
    }

    input[type="text"],
    textarea {
      padding: 8px;
      margin-bottom: 15px;
      border-radius: 4px;
      border: 1px solid #ccc;
      width: calc(100% - 18px);
    }

    button {
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      background-color: #007bff;
      color: #fff;
      cursor: pointer;
      transition: background-color 0.3s ease;
      width: 100%;
      display: block;
    }

    button:hover {
      background-color: #0056b3;
    }

    #message {
      display: none;
      color: green;
      margin-top: 10px;
    }

    #diagnosticInfo {
      max-width: 600px;
      margin: 20px auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      display: none;
    }

    #diagnosticTable {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    #diagnosticTable th, #diagnosticTable td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: left;
    }

    #diagnosticTable th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <!-- Formulario para ingresar el ID del paciente y crear el diagnóstico -->
  <div id="crearDiagnostico">
    <form id="diagnosticForm">
      <label for="patientId">ID del Paciente:</label>
      <input type="text" id="patientId" name="patientId" required>
      <label for="diagnosticCode">Código del diagnóstico:</label>
      <input type="text" id="diagnosticCode" name="diagnosticCode" required>
      <label for="reportConclusion">Conclusión del informe:</label>
      <textarea id="reportConclusion" name="reportConclusion" rows="4" cols="50"></textarea>
      <button type="button" id="createDiagnosticBtn">Crear Diagnóstico</button>
      <p id="message" style="display: none;">Diagnóstico almacenado con éxito</p>
    </form>
  </div>

  <!-- Tabla para mostrar el código del diagnóstico y la conclusión -->
  <div id="diagnosticInfo">
    <h2>Información del Diagnóstico</h2>
    <table id="diagnosticTable">
      <thead>
        <tr>
          <th>Código del Diagnóstico</th>
          <th>Conclusión del Informe</th>
        </tr>
      </thead>
      <tbody>
        <!-- Los datos se llenarán aquí -->
      </tbody>
    </table>
  </div>

  <!-- Script para interactuar con la API FHIR y crear el Diagnóstico -->
  <script>
    document.getElementById('createDiagnosticBtn').addEventListener('click', function() {
      const patientId = document.getElementById('patientId').value;
      const diagnosticCode = document.getElementById('diagnosticCode').value;
      const reportConclusion = document.getElementById('reportConclusion').value;

      // Consultar información del paciente por su ID
      fetch(`https://hapi.fhir.org/baseR4/Patient/${patientId}`)
        .then(response => response.json())
        .then(data => {
          // Verificar si el paciente existe
          if (data.resourceType === 'Patient') {
            const diagnosticReport = {
              resourceType: 'DiagnosticReport',
              status: 'final',
              code: {
                coding: [
                  {
                    system: 'http://loinc.org',
                    code: diagnosticCode,
                    display: 'Your Diagnostic Name',
                  },
                ],
                text: 'Your Diagnostic Name',
              },
              subject: {
                reference: `Patient/${patientId}`,
              },
              conclusion: reportConclusion,
            };

            // Guardar el diagnóstico en la base de datos
            fetch('https://hapi.fhir.org/baseR4/DiagnosticReport', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(diagnosticReport),
            })
            .then(() => {
              // Mostrar información del diagnóstico en la tabla
              const diagnosticTable = document.getElementById('diagnosticTable');
              const row = diagnosticTable.insertRow();
              const codeCell = row.insertCell(0);
              const conclusionCell = row.insertCell(1);
              codeCell.textContent = diagnosticCode;
              conclusionCell.textContent = reportConclusion;

              // Mostrar la tabla después de guardar el diagnóstico
              document.getElementById('diagnosticInfo').style.display = 'block';
              document.getElementById('message').style.display = 'block';
            })
            .catch(error => {
              console.error('Error al guardar el diagnóstico:', error);
              alert('Hubo un error al guardar el diagnóstico.');
            });
          } else {
            alert('Paciente no encontrado. Ingrese un ID válido.');
          }
        })
        .catch(error => {
          console.error('Error al obtener datos del paciente:', error);
          alert('Hubo un error al obtener datos del paciente.');
        });
    });
  </script>
</body>
</html>
