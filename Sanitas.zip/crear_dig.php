<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Crear Diagnóstico HL7</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      background-color: #f4f4f4;
    }

    h2 {
      color: #333;
    }

    #resultado {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      margin-bottom: 20px;
    }

    form {
      display: flex;
      flex-direction: column;
      max-width: 400px;
      margin: 0 auto;
    }

    label {
      margin-bottom: 5px;
      color: #333;
    }

    input[type="text"],
    textarea {
      padding: 8px;
      margin-bottom: 15px;
      border-radius: 4px;
      border: 1px solid #ccc;
    }

    button {
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      background-color: #007bff;
      color: #fff;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #0056b3;
    }

    #message {
      display: none;
      color: green;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <!-- Contenedor para mostrar los datos del paciente -->
  <div id="resultado"></div>

  <!-- Formulario para ingresar datos del diagnóstico -->
  <div id="formulario">
    <h2>Crear Diagnóstico HL7</h2>
    <form id="diagnosticForm">
      <label for="diagnosticCode">Código del diagnóstico:</label>
      <input type="text" id="diagnosticCode" name="diagnosticCode" required>

      <label for="reportConclusion">Conclusión del informe:</label>
      <textarea id="reportConclusion" name="reportConclusion" rows="4" cols="50"></textarea>

      <button type="button" id="createDiagnosticBtn">Crear Diagnóstico</button>
      <p id="message">Diagnóstico almacenado con éxito</p>
    </form>
  </div>

  <!-- Script para interactuar con la API FHIR y crear el Diagnóstico -->
  <script>
    const patientId = '38560405'; // ID del paciente que deseas consultar
    const contenedorResultado = document.getElementById('resultado');
    const diagnosticReport = {};
    const message = document.getElementById('message');

    fetch(`https://hapi.fhir.org/baseR4/Patient/${patientId}`)
      .then(response => response.json())
      .then(data => {
        const parrafoNombre = document.createElement('p');
        parrafoNombre.textContent = `Nombre: ${data.name[0].given.join(' ') + ' ' + data.name[0].family}`;

        const parrafoFechaNacimiento = document.createElement('p');
        parrafoFechaNacimiento.textContent = `Fecha de Nacimiento: ${data.birthDate}`;

        const parrafoDireccion = document.createElement('p');
        parrafoDireccion.textContent = `Dirección: ${data.address && data.address[0] ? data.address[0].text : 'Dirección no disponible'}`;

        contenedorResultado.appendChild(parrafoNombre);
        contenedorResultado.appendChild(parrafoFechaNacimiento);
        contenedorResultado.appendChild(parrafoDireccion);

        document.getElementById('createDiagnosticBtn').addEventListener('click', function() {
          const diagnosticCode = document.getElementById('diagnosticCode').value;
          const reportConclusion = document.getElementById('reportConclusion').value;

          diagnosticReport.resourceType = 'DiagnosticReport';
          diagnosticReport.id = 'example-diagnostic-report';
          diagnosticReport.status = 'final';
          diagnosticReport.code = {
            coding: [
              {
                system: 'http://loinc.org',
                code: diagnosticCode,
                display: 'Your Diagnostic Name',
              },
            ],
            text: 'Your Diagnostic Name',
          };
          diagnosticReport.subject = {
            reference: `Patient/${patientId}`,
          };
          diagnosticReport.conclusion = reportConclusion;

          message.style.display = 'block';

          setTimeout(() => {
            message.style.display = 'none';
            contenedorResultado.innerHTML = '';
            contenedorResultado.appendChild(parrafoNombre);
            contenedorResultado.appendChild(parrafoFechaNacimiento);
            contenedorResultado.appendChild(parrafoDireccion);
          }, 3000);
        });
      })
      .catch(error => {
        console.error('Error al obtener datos del paciente:', error);
      });
  </script>
</body>
</html>
